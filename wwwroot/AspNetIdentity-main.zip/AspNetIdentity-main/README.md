This repo contains the source code for ASP.NET Identity 2.1, which used to live at: https://aspnetidentity.codeplex.com/
