Antiforgery
======================

Antiforgery system for generating secure tokens to prevent Cross-Site Request Forgery attacks.

This project is part of ASP.NET Core. You can find documentation and getting started instructions for ASP.NET Core at the [AspNetCore](https://github.com/dotnet/aspnetcore) repo.
