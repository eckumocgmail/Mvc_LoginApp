# Area Owners

The below table lists all the `area-`labels used in the `aspnetcore` repository and their owners:

| Area label | Owner | Description|
|--- | ---| --- |
| area-blazor | mkArtakMSFT | Blazor server and Blazor WASM related |
| area-commandlinetools |  mkArtakMSFT | dev certs, dotnet watch,  |
| area-dataprotection | Pilchie | |
| area-grpc | shirhatti | |
| area-healthchecks | mkArtakMSFT | |
| area-identity | blowdart | |
| area-infrastructure | dougbu | |
| area-mvc | mkArtakMSFT | |
| area-perf | sebastienros | |
| area-security | blowdart | |
| area-runtime | BrennanConroy | |
| area-signalr | BrennanConroy | |
